from django import template
from modawana.models import Post,Caterory

register=template.Library()
@register.inclusion_tag('modawana/latest-posts.html')

def least_posts():

    context = {
        'l_posts': Post.objects.all()[0:5]
    }
    return context

@register.inclusion_tag('modawana/category.html')

def post_category():
    context={
        'NpostCategory':Category.objects.all()

    }
    return context