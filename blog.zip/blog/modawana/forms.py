from django import forms
from .models import Comment ,Post ,Caterory

choices= Caterory.objects.all().values_list("mycategory","mycategory")
class NewComment(forms.ModelForm):
    class Meta :
        model= Comment
        fields=("name",'email','content',)

class CreatNewpost(forms.ModelForm):
    class Meta:
        model= Post
        fields=('title','imagpost','content','category','author',)

        widgets= {
       'category': forms.Select(choices=choices ,attrs ={'class':'form_control'} ),
      }