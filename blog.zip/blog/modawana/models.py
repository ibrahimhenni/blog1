from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
#from ckeditor.fields import RichTextField
from django.urls import reverse




class Caterory (models.Model):
    mycategory = models.CharField(max_length=100,)

    def __str__(self):
        return self.mycategory


class Post (models.Model):
  
    title = models.CharField(max_length=50,)
    imagpost = models.ImageField(default='imagpost.png', upload_to='profil_picturs',null=True ,blank=True)
    content = models.TextField()
    category= models.TextField (max_length=60, default= 'food')
    #content= RichTextField( blank= True , null=True)
    post_date = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, verbose_name="Admin", on_delete=models.CASCADE)
    
    def __str__(self):
        return self.title

    class Meta:
        ordering=('-post_date',) 

    def get_absolute_url(self):
        #return '/detail/{}'.format(self.pk)
        return reverse('detail', args=[self.pk])

class Comment (models.Model):
    name = models.CharField(max_length=50,)
    email = models.EmailField()
    content= models.TextField(max_length=350,verbose_name='Comment')
    comment_date =models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=False)
    post = models.ForeignKey(Post, on_delete=models.CASCADE , related_name='comment')

    def __str__(self):
        
        return f'Comment {self.name} in {self.post}.'
    
    class Meta:
        ordering=('-comment_date',) 