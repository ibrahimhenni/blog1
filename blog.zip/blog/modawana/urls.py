from django.urls import path
from .import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns =[
    
    path('', views.index_func ,name= "home"),
    path('about',views.about_func ,name= "about"),
    path('detail/<int:post_id>/',views.detailpost_func ,name="detail"),
    path('category/<str:cats>/', views.category_func, name="category"),
    path('new_post', views.newPost_func.as_view(),name ='new-post'),
    path('detail/<slug:id_post>/update',views.UpdateNew_post.as_view() ,name="post-update"),

    ]+static(settings.MEDIA_URL , document_root = settings.MEDIA_ROOT)