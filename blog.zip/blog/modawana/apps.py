from django.apps import AppConfig


class ModawanaConfig(AppConfig):
    name = 'modawana'
