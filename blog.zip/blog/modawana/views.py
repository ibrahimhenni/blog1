from django.shortcuts import render ,get_object_or_404
from .models import Post ,Caterory ,Comment
from .forms import NewComment , CreatNewpost
from django.db.models import Q
from django.core.paginator import Paginator ,PageNotAnInteger ,EmptyPage
from django.views.generic import CreateView ,UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin 



# Create your views here.
def index_func (request ):
    posts = Post.objects.all()
    cats= Caterory.objects.all()
    
    paginator = Paginator(posts ,3)
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page (paginator.num_page)

    context ={
        'title': 'Home',
        'posts': posts,
        'page': page,
        
        
        }

    return render(request,'modawana/index.html',context )

    def get_context_data(self ,*args ,**kwargs):
        cat_menu = Category.objects.all()
        context = super(index_func,self).get_context_data(*args ,**kwargs)
        context["cat_menu"]= cat_menu
        return context


def category_func (request ,cats):
    category_post = Post.objects.filter(category = cats)
   
    context={
        'title':'category',
        'category_post':category_post,
        'cats':cats ,
    }
    return render(request, 'modawana/category.html',context)





def about_func (request):
    categorys = Caterory.objects.all(),
   
    return render(request, 'modawana/about.html')



def detailpost_func(request, post_id):
    
    post= get_object_or_404 (Post, pk=post_id)
    comments = post.comment.filter(active=True)
    
    if request.method == "POST":
        comment_forms= NewComment(data=request.POST)
        if comment_forms.is_valid(): 
            new_Comment =comment_forms.save(commit=False)
            new_Comment.post = post
            new_Comment.save()
            comment_forms = NewComment()
    else:
        comment_forms= NewComment()

    context={
        'title':post,
        'post':post ,
        'comments':comments,
        'comment_forms':comment_forms, 
        'categorys':Caterory.objects.all(),
        
    }

       

    return render(request ,'modawana/detail.html', context)




    

def search_func(request):
    if request.method=="GET":
        search=request.GET.get('search')
        posts= Post.objects.filter(Q(title__icontains=your_search_query) | Q(intro__icontains=your_search_query) | Q(content__icontains=your_search_query))
    return render(request,'modawana/search.html',{'posts':posts})


class newPost_func (CreateView ,LoginRequiredMixin ):
    model = Post
    form_class = CreatNewpost
    #fields = ['title','imagpost','content','category','author']
    template_name = 'modawana/new_post.html'
    
    
    def form_valid(self ,form):
       
        form.instance.author=self.request.user
        return super().form_valid(form)

        

class UpdateNew_post (LoginRequiredMixin ,UpdateView ):
    model = Post
    template_name = 'modawana/new_post.html'
    
    def form_valid(self ,form):
       
        form.instance.author=self.request.user
        return super().form_valid(form)