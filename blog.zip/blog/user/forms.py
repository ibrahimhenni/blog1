from django import forms
from django.contrib.auth.models import User
from .models import Profile

class UserCreationForm(forms.ModelForm):
    username= forms.CharField()
    first_name=forms.CharField()
    last_name=forms.CharField()
    email= forms.EmailField()
    password1=forms.CharField(label='Password' , widget=forms.PasswordInput(),min_length=8)
    password2=forms.CharField(label='Confirm password' , widget=forms.PasswordInput(),min_length=8)
    class Meta:
        model = User
        fields=('username','first_name','last_name','email','password1','password2')

    def clean_password(self):
        cd= self.clean_data
        if cd['password1'] != cd ['password2']:
            raise forms.ValidationError ('Password is not Identical')
        return cd['passowrd2'] 
          
    def clean_username(self):
        cd=self.cleaned_data
        if User.objects.filter(username= cd['username']).exists():
            raise forms.ValidationError('This name is already registered')
        return cd['username']

class update_userform(forms.ModelForm):
    class Meta:
        model = User
        fields=('first_name','last_name','email')

class update_profile(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ('image',)
