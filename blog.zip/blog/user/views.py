from django.shortcuts import render , redirect
from .forms import UserCreationForm ,update_profile ,update_userform
from django.contrib import messages
from modawana.models import Post
from django.contrib.auth.decorators import login_required


# Create your views here.

def register_func(request):
    if request.method=="POST":
       form= UserCreationForm(request.POST)
       if form.is_valid():
           New_user=form.save(commit=False)
           New_user.set_password(form.cleaned_data['password1'])
           New_user.save()
           
           messages.success(request, f'Hello {New_user} your count is created')
           return redirect ('login')
    else:
        form= UserCreationForm()
    context={
        'title':'register',
        'myform':form ,
    }
    return render(request,"user/register.html",context)


def profile_func(request):
    posts=Post.objects.filter(author=request.user)
    context={
        'title':'Myprofil',
        'posts':posts
    }
    return render(request,'user/profile.html',context)



@login_required(login_url='login')
def profileUpdate_func(request):
    if request.method== "POST":

        user_form = update_userform(request.POST , instance=request.user)
        profile_form = update_profile(request.POST ,request.FILES ,instance=request.user.profile)
        if user_form.is_valid and profile_form.is_valid:
            user_form.save()
            profile_form.save()

            messages.success(request, 'your profile is update')
            return redirect ('profile')

    else:
        
        user_form = update_userform(instance=(request.user))
        profile_form = update_profile(instance=(request.user.profile))

    context={

        'title':'profile update',
        'user_form':user_form,
        'profile_form':profile_form,

    }
    return render (request,'user/profile_update.html',context)