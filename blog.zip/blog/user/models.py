from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save


# Create your models here.
class Profile(models.Model):
    image=models.ImageField(default='profile.png', upload_to='profil_picturs')
    user=models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.user.username} profile'


def Create_profile(sender, **kwarg):
    if kwarg['created']:
        user_profile = Profile.objects.create(user=kwarg['instance'])

post_save.connect(Create_profile , sender=User)        


